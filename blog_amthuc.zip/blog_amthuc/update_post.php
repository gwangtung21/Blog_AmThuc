<?php
include 'db.php'; // Kết nối cơ sở dữ liệu

// Kiểm tra xem dữ liệu đã được gửi từ biểu mẫu chưa
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy dữ liệu từ biểu mẫu
    $post_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $content = isset($_POST['content']) ? trim($_POST['content']) : '';
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;

    // Kiểm tra xem các trường có hợp lệ không
    if (!empty($title) && !empty($content) && $category_id > 0) {
        // Cập nhật bài viết vào cơ sở dữ liệu
        $stmt = $conn->prepare("UPDATE posts SET title = ?, content = ?, category_id = ? WHERE id = ?");
        $stmt->bind_param("ssii", $title, $content, $category_id, $post_id);

        if ($stmt->execute()) {
            // Chuyển hướng về trang chính sau khi cập nhật bài viết thành công
            header("Location: index.php");
            exit();
        } else {
            echo "Lỗi: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Vui lòng điền đầy đủ thông tin.";
    }
} else {
    echo "Yêu cầu không hợp lệ.";
}

// Đóng kết nối
$conn->close();
?>