<?php
include 'db.php'; // Kết nối cơ sở dữ liệu

// Lấy ID danh mục từ URL
$category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Lấy tên danh mục
$category_result = $conn->query("SELECT name FROM categories WHERE id = $category_id");
$category = $category_result->fetch_assoc();

if (!$category) {
    die("Danh mục không tồn tại.");
}

// Lấy danh sách bài viết theo danh mục
$result = $conn->query("SELECT * FROM posts WHERE category_id = $category_id ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bài Viết trong Danh Mục: <?php echo htmlspecialchars($category['name']); ?></title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <header>
        <h1>Bài Viết trong Danh Mục: <?php echo htmlspecialchars($category['name']); ?></h1>
        <nav>
            <ul>
                <li><a href="index.php">Trang Chủ</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <article>
                    <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                    <p><?php echo htmlspecialchars(substr($row['content'], 0, 150)) . '...'; ?></p>
                    <a href="post.php?id=<?php echo $row['id']; ?>">Đọc thêm</a>
                    <small>Ngày đăng: <?php echo $row['created_at']; ?></small>
                </article>
                <hr>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Không có bài viết nào trong danh mục này.</p>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Blog Ẩm Thực. Tất cả quyền được bảo lưu.</p>
    </footer>
</body>
</html>

<?php
$conn->close(); // Đóng kết nối
?>