<?php
session_start(); // Bắt đầu phiên làm việc
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Chuyển hướng đến trang đăng nhập nếu chưa đăng nhập
    exit();
}

// Giả sử bạn đã lấy thông tin người dùng từ cơ sở dữ liệu
$username = $_SESSION['username']; // Tên người dùng từ phiên
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang Quản Trị</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- Kết nối tệp CSS -->
</head>
<body>
    <header>
        <h1>Chào mừng, <?php echo htmlspecialchars($username); ?>!</h1>
        <nav>
            <ul>
                <li><a href="add_post.php">Thêm Bài Viết</a></li>
                <li><a href="my_posts.php">Xem Bài Viết Của Tôi</a></li>
                <li><a href="profile.php">Cập Nhật Thông Tin</a></li>
                <li><a href="logout.php">Đăng Xuất</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Thông tin tài khoản</h2>
        <p>Tên người dùng: <?php echo htmlspecialchars($username); ?></p>
        <p>Email: <?php echo htmlspecialchars($_SESSION['email']); // Giả sử bạn đã lưu email trong phiên ?></p>

        <h2>Thông báo</h2>
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; ?>
                <?php unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Blog Ẩm Thực. Tất cả quyền được bảo lưu.</p>
    </footer>
</body>
</html>