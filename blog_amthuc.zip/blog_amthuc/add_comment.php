<?php
include 'db.php'; // Kết nối cơ sở dữ liệu

// Kiểm tra xem dữ liệu đã được gửi từ biểu mẫu chưa
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy dữ liệu từ biểu mẫu
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    $author = isset($_POST['author']) ? trim($_POST['author']) : '';
    $content = isset($_POST['content']) ? trim($_POST['content']) : '';

    // Kiểm tra xem các trường có hợp lệ không
    if (!empty($author) && !empty($content) && $post_id > 0) {
        // Thêm bình luận vào cơ sở dữ liệu
        $stmt = $conn->prepare("INSERT INTO comments (post_id, author, content) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $post_id, $author, $content);

        if ($stmt->execute()) {
            // Chuyển hướng về trang bài viết sau khi thêm bình luận thành công
            header("Location: post.php?id=" . $post_id);
            exit();
        } else {
            echo "Lỗi: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Vui lòng điền đầy đủ thông tin.";
    }
} else {
    echo "Yêu cầu không hợp lệ.";
}

// Đóng kết nối
$conn->close();
?>