<?php
include 'db.php'; // Kết nối cơ sở dữ liệu

// Lấy ID bài viết từ URL
$post_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Xóa bài viết khỏi cơ sở dữ liệu
if ($post_id > 0) {
    $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->bind_param("i", $post_id);

    if ($stmt->execute()) {
        // Chuyển hướng về trang chính sau khi xóa bài viết thành công
        header("Location: index.php");
        exit();
    } else {
        echo "Lỗi: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "ID bài viết không hợp lệ.";
}

// Đóng kết nối
$conn->close();
?>