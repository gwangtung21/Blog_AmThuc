<?php
include 'db.php'; // Kết nối cơ sở dữ liệu

// Lấy danh sách danh mục từ cơ sở dữ liệu
$categories = $conn->query("SELECT * FROM categories");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Bài Viết Mới</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- Kết nối tệp CSS -->
    <script>
        document.getElementById('category').addEventListener('change', function() {
            if (this.value === 'new') {
                window.location.href = 'add_category.php'; // Chuyển hướng đến trang thêm danh mục
            }
        });
    </script>
</head>
<body>
    <header>
        <h1>Thêm Bài Viết Mới</h1>
        <nav>
            <ul>
                <li><a href="index.php">Trang Chủ</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <form action="save_post.php" method="POST">
            <label for="title">Tiêu đề:</label><br>
            <input type="text" id="title" name="title" required><br><br>

            <label for="content">Nội dung:</label><br>
            <textarea id="content" name="content" rows="10" required></textarea><br><br>

            <label for="category">Danh mục:</label><br>
            <select id="category" name="category_id" required>
                <option value="">Chọn danh mục</option> <!-- Tùy chọn mặc định -->
                <?php while ($category = $categories->fetch_assoc()): ?>
                    <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                <?php endwhile; ?>
                <option value="new">Thêm danh mục mới</option> <!-- Tùy chọn thêm danh mục mới -->
            </select><br><br>

            <button type="submit">Đăng Bài</button>
        </form>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Blog Ẩm Thực. Tất cả quyền được bảo lưu.</p>
    </footer>
</body>
</html>

<?php
$conn->close(); // Đóng kết nối
?>