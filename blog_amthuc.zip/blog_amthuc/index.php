<?php
session_start(); // Bắt đầu phiên làm việc
include 'db.php'; // Kết nối cơ sở dữ liệu

// Lấy danh sách bài viết từ cơ sở dữ liệu
$result = $conn->query("SELECT * FROM posts ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Ẩm Thực</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- Kết nối tệp CSS -->
</head>
<body>
    <header>
        <h1>Blog Ẩm Thực</h1>
        <nav>
            <ul>
                <li><a href="index.php">Trang Chủ</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="add_post.php">Thêm Bài Viết</a></li>
                    <li><a href="logout.php">Đăng Xuất</a></li>
                <?php else: ?>
                    <li><a href="login.php">Đăng Nhập</a></li>
                    <li><a href="register.php">Đăng Ký</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Danh Sách Bài Viết</h2>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <article>
                    <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                    <p><?php echo htmlspecialchars(substr($row['content'], 0, 150)) . '...'; ?></p>
                    <small>Danh mục: 
                        <?php
                        // Lấy tên danh mục từ ID
                        $category_id = $row['category_id'];
                        $category_result = $conn->query("SELECT name FROM categories WHERE id = $category_id");
                        $category = $category_result->fetch_assoc();
                        ?>
                        <a href="category.php?id=<?php echo $category_id; ?>"><?php echo htmlspecialchars($category['name']); ?></a>
                    </small>
                    <a href="post.php?id=<?php echo $row['id']; ?>">Đọc thêm</a>
                    <small>Ngày đăng: <?php echo $row['created_at']; ?></small>
                    <br>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <a href="edit_post.php?id=<?php echo $row['id']; ?>">Chỉnh sửa</a> | 
                        <a href="delete_post.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa bài viết này không?');">Xóa</a>
                    <?php endif; ?>
                </article>
                <hr>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Chưa có bài viết nào.</p>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Blog Ẩm Thực. Tất cả quyền được bảo lưu.</p>
    </footer>
</body>
</html>

<?php
$conn->close(); // Đóng kết nối
?>