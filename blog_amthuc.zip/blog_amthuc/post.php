<?php
include 'db.php'; // Kết nối cơ sở dữ liệu

// Lấy ID bài viết từ URL
$post_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Lấy thông tin bài viết
$post_result = $conn->query("SELECT * FROM posts WHERE id = $post_id");
$post = $post_result->fetch_assoc();

// Kiểm tra xem bài viết có tồn tại không
if (!$post) {
    die("Bài viết không tồn tại.");
}

// Lấy bình luận cho bài viết
$comments_result = $conn->query("SELECT * FROM comments WHERE post_id = $post_id ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($post['title']); ?></title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <header>
        <h1>Blog Ẩm Thực</h1>
        <nav>
            <ul>
                <li><a href="add_post.php">Thêm Bài Viết</a></li>
                <li><a href="index.php">Trang Chủ</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2><?php echo htmlspecialchars($post['title']); ?></h2>
        <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p> <!-- Hiển thị nội dung bài viết -->

        <h3>Bình luận</h3>
        <?php while($comment = $comments_result->fetch_assoc()): ?>
            <div>
                <strong><?php echo htmlspecialchars($comment['author']); ?></strong>
                <p><?php echo nl2br(htmlspecialchars($comment['content'])); ?></p>
                <small><?php echo htmlspecialchars($comment['created_at']); ?></small>
            </div>
        <?php endwhile; ?>

        <h3>Thêm bình luận</h3>
        <form action="add_comment.php" method="POST">
            <input type="hidden" name="post_id" value="<?php echo $post_id; ?>">
            <input type="text" name="author" placeholder="Tên của bạn" required>
            <textarea name="content" placeholder="Nội dung bình luận" required></textarea>
            <button type="submit">Gửi bình luận</button>
        </form>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Blog Ẩm Thực. Tất cả quyền được bảo lưu.</p>
    </footer>
</body>
</html>

<?php
$conn->close(); // Đóng kết nối
?>