<?php
session_start(); // Bắt đầu phiên làm việc
session_unset(); // Xóa tất cả các biến phiên
session_destroy(); // Hủy phiên
header("Location: login.php"); // Chuyển hướng về trang đăng nhập
exit();
?>