<?php
include 'db.php'; // Kết nối cơ sở dữ liệu

// Kiểm tra xem dữ liệu đã được gửi từ biểu mẫu chưa
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy tên danh mục từ biểu mẫu
    $category_name = isset($_POST['category_name']) ? trim($_POST['category_name']) : '';

    // Kiểm tra xem tên danh mục có hợp lệ không
    if (!empty($category_name)) {
        // Thêm danh mục vào cơ sở dữ liệu
        $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $category_name);

        if ($stmt->execute()) {
            // Chuyển hướng về trang chính sau khi thêm danh mục thành công
            header("Location: index.php");
            exit();
        } else {
            echo "Lỗi: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Vui lòng nhập tên danh mục.";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Danh Mục Mới</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- Kết nối tệp CSS -->
</head>
<body>
    <header>
        <h1>Thêm Danh Mục Mới</h1>
        <nav>
            <ul>
                <li><a href="index.php">Trang Chủ</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <form action="add_category.php" method="POST">
            <label for="category_name">Tên danh mục:</label><br>
            <input type="text" id="category_name" name="category_name" required><br><br>

            <button type="submit">Thêm Danh Mục</button>
        </form>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Blog Ẩm Thực. Tất cả quyền được bảo lưu.</p>
    </footer>
</body>
</html>

<?php
$conn->close(); // Đóng kết nối
?>