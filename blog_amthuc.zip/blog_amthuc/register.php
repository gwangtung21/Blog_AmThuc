<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký Tài Khoản</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- Kết nối tệp CSS -->
</head>
<body>
    <header>
        <h1>Đăng Ký Tài Khoản</h1>
    </header>

    <main>
        <form action="register_process.php" method="POST">
            <label for="username">Tên người dùng:</label><br>
            <input type="text" id="username" name="username" required><br><br>

            <label for="password">Mật khẩu:</label><br>
            <input type="password" id="password" name="password" required><br><br>

            <button type="submit">Đăng Ký</button>
        </form>
        <p>Đã có tài khoản? <a href="login.php">Đăng Nhập</a></p>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Blog Ẩm Thực. Tất cả quyền được bảo lưu.</p>
    </footer>
</body>
</html>