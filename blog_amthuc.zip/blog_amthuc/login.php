<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Nhập Tài Khoản</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- Kết nối tệp CSS -->
</head>
<body>
    <header>
        <h1>Đăng Nhập Tài Khoản</h1>
    </header>

    <main>
        <form action="login_process.php" method="POST">
            <label for="username">Tên người dùng:</label><br>
            <input type="text" id="username" name="username" required><br><br>

            <label for="password">Mật khẩu:</label><br>
            <input type="password" id="password" name="password" required><br><br>

            <button type="submit">Đăng Nhập</button>
        </form>
        <p>Chưa có tài khoản? <a href="register.php">Đăng Ký</a></p>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Blog Ẩm Thực. Tất cả quyền được bảo lưu.</p>
    </footer>
</body>
</html>