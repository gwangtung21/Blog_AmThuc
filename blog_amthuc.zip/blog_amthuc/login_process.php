<?php
session_start(); // Bắt đầu phiên làm việc
include 'db.php'; // Kết nối cơ sở dữ liệu

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy thông tin từ biểu mẫu
    $username = isset($_POST['username']) ? trim(string: $_POST['username']) : '';
    $password = isset($_POST['password']) ? trim(string: $_POST['password']) : '';

    // Kiểm tra xem các trường có rỗng không
    if (!empty($username) && !empty($password)) {
        // Truy vấn người dùng từ cơ sở dữ liệu
        $stmt = $conn->prepare(query: "SELECT * FROM users WHERE username = ?");
        $stmt->bind_param(types: "s", var: $username);
        $stmt->execute();
        $result = $stmt->get_result();

        // Kiểm tra xem người dùng có tồn tại không
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            // Kiểm tra mật khẩu
            if (password_verify(password: $password, hash: $user['password'])) {
                // Lưu thông tin người dùng vào phiên
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['success'] = "Đăng nhập thành công!";

                // Chuyển hướng về trang dashboard
                header(header: "Location: dashboard.php");
                exit(); // Đảm bảo thoát sau khi chuyển hướng
            } else {
                // Mật khẩu không chính xác
                $_SESSION['error'] = "Mật khẩu không chính xác.";
                header(header: "Location: login.php");
                exit();
            }
        } else {
            // Tên người dùng không tồn tại
            $_SESSION['error'] = "Tên người dùng không tồn tại.";
            header("Location: login.php");
            exit();
        }

        $stmt->close();
    } else {
        // Thông báo nếu các trường không được điền đầy đủ
        $_SESSION['error'] = "Vui lòng điền đầy đủ thông tin.";
        header(header: "Location: login.php");
        exit();
    }
} else {
    // Nếu không phải là yêu cầu POST
    $_SESSION['error'] = "Yêu cầu không hợp lệ.";
    header(header: "Location: login.php");
    exit();
}

// Đóng kết nối
$conn->close();
?>