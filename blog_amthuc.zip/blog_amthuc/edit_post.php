<?php
include 'db.php'; // Kết nối cơ sở dữ liệu

// Lấy ID bài viết từ URL
$post_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Lấy thông tin bài viết từ cơ sở dữ liệu
$post_result = $conn->query("SELECT * FROM posts WHERE id = $post_id");
$post = $post_result->fetch_assoc();

if (!$post) {
    die("Bài viết không tồn tại.");
}

// Lấy danh sách danh mục
$categories = $conn->query("SELECT * FROM categories");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chỉnh Sửa Bài Viết</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <header>
        <h1>Chỉnh Sửa Bài Viết</h1>
        <nav>
            <ul>
                <li><a href="index.php">Trang Chủ</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <form action="update_post.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $post['id']; ?>">
            <label for="title">Tiêu đề:</label><br>
            <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($post['title']); ?>" required><br><br>

            <label for="content">Nội dung:</label><br>
            <textarea id="content" name="content" rows="10" required><?php echo htmlspecialchars($post['content']); ?></textarea><br><br>

            <label for="category">Danh mục:</label><br>
            <select id="category" name="category_id" required>
                <?php while ($category = $categories->fetch_assoc()): ?>
                    <option value="<?php echo $category['id']; ?>" <?php echo $category['id'] == $post['category_id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($category['name']); ?>
                    </option>
                <?php endwhile; ?>
            </select><br><br>

            <button type="submit">Cập nhật Bài Viết</button>
        </form>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Blog Ẩm Thực. Tất cả quyền được bảo lưu.</p>
    </footer>
</body>
</html>

<?php
$conn->close(); // Đóng kết nối
?>