<?php
include 'db.php'; // Kết nối cơ sở dữ liệu

// Kiểm tra xem dữ liệu đã được gửi từ biểu mẫu chưa
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy dữ liệu từ biểu mẫu
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $content = isset($_POST['content']) ? trim($_POST['content']) : '';
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0; // Lấy category_id từ biểu mẫu

    // Kiểm tra xem các trường có hợp lệ không
    if (!empty($title) && !empty($content) && $category_id > 0) {
        // Thêm bài viết vào cơ sở dữ liệu
        $stmt = $conn->prepare("INSERT INTO posts (title, content, category_id, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("ssi", $title, $content, $category_id); // Liên kết các tham số

        if ($stmt->execute()) {
            // Chuyển hướng về trang chính sau khi thêm bài viết thành công
            header("Location: index.php");
            exit();
        } else {
            echo "Lỗi: " . $stmt->error; // Hiển thị lỗi nếu có
        }

        $stmt->close();
    } else {
        // Hiển thị thông báo nếu có trường không hợp lệ
        if (empty($title)) {
            echo "Vui lòng nhập tiêu đề bài viết.<br>";
        }
        if (empty($content)) {
            echo "Vui lòng nhập nội dung bài viết.<br>";
        }
        if ($category_id <= 0) {
            echo "Vui lòng chọn danh mục cho bài viết.<br>";
        }
    }
} else {
    echo "Yêu cầu không hợp lệ.";
}

// Đóng kết nối
$conn->close();
?>