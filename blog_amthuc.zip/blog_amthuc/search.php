<?php
include 'db.php'; // Kết nối cơ sở dữ liệu

// Lấy từ khóa tìm kiếm từ URL
$query = isset($_GET['query']) ? trim($_GET['query']) : '';

// Lấy danh sách bài viết theo từ khóa
$result = $conn->query("SELECT * FROM posts WHERE title LIKE '%$query%' OR content LIKE '%$query%' ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kết quả tìm kiếm</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <header>
        <h1>Blog Ẩm Thực</h1>
        <nav>
            <ul>
                <li><a href="add_post.php">Thêm Bài Viết</a></li>
                <li><a href="index.php">Trang Chủ</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Kết quả tìm kiếm cho: "<?php echo htmlspecialchars($query); ?>"</h2>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <article>
                    <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                    <p><?php echo htmlspecialchars(substr($row['content'], 0, 150)) . '...'; ?></p>
                    <a href="post.php?id=<?php echo $row['id']; ?>">Đọc thêm</a>
                    <small>Ngày đăng: <?php echo $row['created_at']; ?></small>
                </article>
                <hr>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Không tìm thấy bài viết nào.</p>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Blog Ẩm Thực. Tất cả quyền được bảo lưu.</p>
    </footer>
</body>
</html>

<?php
$conn->close(); // Đóng kết nối
?>